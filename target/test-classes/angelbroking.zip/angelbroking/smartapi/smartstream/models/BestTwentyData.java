package com.angelbroking.smartapi.smartstream.models;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BestTwentyData {
    public BestTwentyData(long quantity2, long price2, short numberOfOrders2) {
		// TODO Auto-generated constructor stub
	}
	private long quantity = -1;
    private long price = -1;
    private short numberOfOrders = -1;
}
