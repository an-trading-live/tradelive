package com.angelbroking.smartapi.smartstream.models;

public class SmartStreamError {
	private Throwable exception;

	public Throwable getException() {
		return exception;
	}

	public void setException(Throwable exception) {
		this.exception = exception;
	}
	
}
