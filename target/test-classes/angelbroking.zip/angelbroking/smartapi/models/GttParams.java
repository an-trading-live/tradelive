package com.angelbroking.smartapi.models;

public class GttParams {
	public Integer id;
	public String tradingsymbol;
	public String exchange;
	public String transactiontype;
	public String producttype;
	public Double price;
	public Integer qty;
	public Double triggerprice;
	public Integer disclosedqty;
	public Integer timeperiod;
	public String symboltoken;

}
