package com.angelbroking.smartapi.models;

public class EstimateChargesParams {

    public String product_type;
    public String transaction_type;
    public String quantity;
    public String price;
    public String exchange;
    public String symbol_name;
    public String token;
}
