package com.angelbroking.smartapi.smartTicker;

public interface SmartWSOnDisconnect {
	void onDisconnected();
}
