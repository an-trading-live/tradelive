package com.angelbroking.smartapi.smartTicker;

public interface SmartWSOnConnect {
    void onConnected();
}
