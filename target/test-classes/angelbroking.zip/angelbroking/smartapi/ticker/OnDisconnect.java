package com.angelbroking.smartapi.ticker;

public interface OnDisconnect {
	void onDisconnected();
}
