package com.angelbroking.smartapi.ticker;

public interface OnConnect {
    void onConnected();
}
